# AWS Orgnization Unit tagging policy implementation
2020-01-16
Enquizit.inc
## Package Contents

a. ctpolicycreator.py

b. deployment.yml

c. ctpolicycreator.zip
## Deployment Steps:

1. Sign-in to master payer account 
2. Upload zip ctpolicycreater.zip to s3 bucket
3. From AWS console go to the cloudformation and create a stack
4. Upload the "deployment.yml" to cloudformation and set `BucketName` as s3 bucket name `LambdaFile` as s3 file Key in cloudformation parameter
5. Run the cloudformation template and it will create all the manadatory polices
6. To update the policy, update the cloudformation template file `deployment.yml` and and execute changeset to update existing policies
7. PolicyType can either be "TAG_POLICY" or "SERVICE_CONTROL_POLICY"
e.g

```
	rTagPolicyInstanceName:
		Type: AWS::CloudFormation::CustomResource
		DependsOn: rTagPolicyApplication
		Properties:
		ServiceToken: !GetAtt PolicyCreatorFn.Arn
		PolicyName: !Sub ${AWS::StackName}-Instance-Name
		PolicyType: TAG_POLICY
		Description: "The name of the server instance."
		PolicyDoc:
			{
				"tags": {
					"Instance Name": {
						"enforced_for": {
							"@@assign": [
								"ec2:instance"
								"ec2:instance2"
							]
						}
					}
				}
			}

```
7. To delete the policy, delete the cloudformation template and it will delete all the polices
